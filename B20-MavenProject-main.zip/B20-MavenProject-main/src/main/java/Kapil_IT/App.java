package Kapil_IT;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        System.out.println("Webhook Job Demo");
        System.out.println("KIT Webhook Job Configuration Demo");
    }
    
}
